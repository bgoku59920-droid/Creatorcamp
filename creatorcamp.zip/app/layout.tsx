import type { Metadata } from 'next';
import './globals.css';
import { Toaster } from 'react-hot-toast';

export const metadata: Metadata = {
  title: 'Creator Camp',
  description: 'Join Creator Camp - Master your craft with Zenvy',
  manifest: '/manifest.json',
  themeColor: '#0A0A0A',
  viewport: 'width=device-width, initial-scale=1, maximum-scale=1',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="font-sans antialiased bg-[#0A0A0A] text-white">
        {children}
        <Toaster position="top-center" />
      </body>
    </html>
  );
}
