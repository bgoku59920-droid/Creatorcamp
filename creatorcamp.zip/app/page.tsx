'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { LogOut, Download, MessageCircle, Award, Users } from 'lucide-react';
import toast from 'react-hot-toast';
import { jsPDF } from 'jspdf';

interface Message {
  id: number;
  text: string;
  isAI: boolean;
}

interface User {
  uid: string;
  displayName: string;
  email: string;
  photoURL: string;
}

const HF_CHAT_URL = process.env.NEXT_PUBLIC_CREATOR_CAMP_HF_CHAT_URL || 'https://your-hf-space.hf.space/chat';
const WHATSAPP_CHANNEL = process.env.NEXT_PUBLIC_WHATSAPP_CHANNEL_URL || '#';
const WHATSAPP_COMMUNITY = process.env.NEXT_PUBLIC_WHATSAPP_COMMUNITY_URL || '#';

export default function CreatorCamp() {
  const [user, setUser] = useState<User | null>(null);
  const [stage, setStage] = useState<'login' | 'onboarding' | 'app'>('login');
  const [onboardingComplete, setOnboardingComplete] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { id: 1, text: "Hello. I am Zenvy. I will guide you through Creator Camp onboarding. Let us begin.", isAI: true }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [onboardingStep, setOnboardingStep] = useState(0);
  const [showChatbot, setShowChatbot] = useState(false);

  // Simulated Google Sign In (Firebase ready)
  const handleGoogleSignIn = () => {
    const mockUser: User = {
      uid: 'user_' + Date.now(),
      displayName: 'Alex Rivera',
      email: 'alex@example.com',
      photoURL: 'https://lh3.googleusercontent.com/a/default-user',
    };
    
    setUser(mockUser);
    setStage('onboarding');
    toast.success('Signed in successfully');
  };

  const signOut = () => {
    setUser(null);
    setStage('login');
    setOnboardingComplete(false);
    setMessages([{ id: 1, text: "Hello. I am Zenvy. I will guide you through Creator Camp onboarding. Let us begin.", isAI: true }]);
    setOnboardingStep(0);
    toast.success('Signed out');
  };

  // Zenvy Onboarding Questions (Conversational)
  const onboardingQuestions = [
    "To begin, tell me what you create or work on.",
    "How do you currently organize your creative or professional work?",
    "What challenges do you face when trying to stay consistent?",
    "Why do you want to join Creator Camp?",
  ];

  const sendOnboardingMessage = async () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now(),
      text: input.trim(),
      isAI: false,
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      const nextStep = onboardingStep + 1;
      
      if (nextStep < onboardingQuestions.length) {
        const aiMessage: Message = {
          id: Date.now() + 1,
          text: onboardingQuestions[nextStep],
          isAI: true,
        };
        setMessages(prev => [...prev, aiMessage]);
        setOnboardingStep(nextStep);
      } else {
        const finalMessage: Message = {
          id: Date.now() + 1,
          text: "Thank you. Your answers show strong commitment and clarity. Welcome to Creator Camp.",
          isAI: true,
        };
        setMessages(prev => [...prev, finalMessage]);
        setTimeout(() => {
          setOnboardingComplete(true);
          setStage('app');
          toast.success('Onboarding complete. Welcome!');
        }, 1200);
      }
      setIsTyping(false);
    }, 900);
  };

  // Download Certificate
  const downloadCertificate = () => {
    if (!user) return;

    const doc = new jsPDF({
      orientation: 'landscape',
      unit: 'mm',
      format: 'a4',
    });

    doc.setFillColor(10, 10, 10);
    doc.rect(0, 0, 297, 210, 'F');

    doc.setDrawColor(59, 130, 246);
    doc.setLineWidth(3);
    doc.rect(15, 15, 267, 180);

    doc.setFontSize(28);
    doc.setTextColor(255, 255, 255);
    doc.text('CREATOR CAMP', 148.5, 55, { align: 'center' });

    doc.setFontSize(16);
    doc.text('Certificate of Completion', 148.5, 70, { align: 'center' });

    doc.setFontSize(22);
    doc.text(user.displayName, 148.5, 105, { align: 'center' });

    doc.setFontSize(13);
    doc.text('Has successfully completed the Creator Camp program', 148.5, 125, { align: 'center' });
    doc.text('and demonstrated exceptional dedication and clarity.', 148.5, 133, { align: 'center' });

    doc.setFontSize(12);
    doc.text('Zenvy • Creator Camp', 148.5, 165, { align: 'center' });

    doc.save('creator_camp_certificate.pdf');
    toast.success('Certificate downloaded');
  };

  // Main App View
  if (stage === 'app' && user) {
    return (
      <div className="app-container min-h-screen pb-20">
        {/* Top Navigation */}
        <nav className="border-b border-white/10 bg-[#0A0A0A]/95 backdrop-blur-lg sticky top-0 z-50">
          <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img src="/logo.png" alt="Creator Camp" className="h-8 w-8" />
              <div>
                <div className="font-semibold tracking-tight">Creator Camp</div>
                <div className="text-[10px] text-white/50 -mt-0.5">by Zenvy</div>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-sm">
                <img src={user.photoURL} alt="" className="w-7 h-7 rounded-full" />
                <span className="hidden md:block">{user.displayName}</span>
              </div>
              <button onClick={signOut} className="p-2 hover:bg-white/5 rounded-lg transition-colors">
                <LogOut size={18} />
              </button>
            </div>
          </div>
        </nav>

        <div className="max-w-6xl mx-auto px-6 pt-10">
          {/* Hero Banner */}
          <div className="relative rounded-3xl overflow-hidden mb-12 h-[340px] flex items-center justify-center bg-black">
            <video 
              src="/banner.mp4" 
              autoPlay 
              loop 
              muted 
              playsInline
              className="absolute inset-0 w-full h-full object-cover opacity-70"
            />
            <div className="relative z-10 text-center px-6">
              <div className="text-6xl font-semibold tracking-tighter mb-3">Welcome to Creator Camp</div>
              <p className="text-xl text-white/70 max-w-md mx-auto">Build. Create. Grow. With guidance from Zenvy.</p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12">
            <button 
              onClick={() => setShowChatbot(true)}
              className="card p-8 rounded-2xl flex flex-col items-start text-left group"
            >
              <MessageCircle className="mb-6 text-[#3B82F6]" size={28} />
              <div className="font-semibold text-xl mb-1">Talk to Zenvy</div>
              <div className="text-white/60">Ask anything. Get guidance.</div>
            </button>

            <button 
              onClick={downloadCertificate}
              className="card p-8 rounded-2xl flex flex-col items-start text-left group"
            >
              <Award className="mb-6 text-[#10B981]" size={28} />
              <div className="font-semibold text-xl mb-1">Download Certificate</div>
              <div className="text-white/60">Your official Creator Camp certificate.</div>
            </button>

            <a 
              href={WHATSAPP_COMMUNITY} 
              target="_blank"
              className="card p-8 rounded-2xl flex flex-col items-start text-left group"
            >
              <Users className="mb-6 text-[#F59E0B]" size={28} />
              <div className="font-semibold text-xl mb-1">Join Community</div>
              <div className="text-white/60">Connect with fellow creators.</div>
            </a>
          </div>

          {/* Main Content */}
          <div className="card p-10 rounded-3xl">
            <div className="max-w-2xl">
              <div className="text-4xl font-semibold tracking-tighter mb-4">Your Journey Starts Here</div>
              <p className="text-lg text-white/70 leading-relaxed mb-8">
                Creator Camp is your space to grow. Zenvy is always here to support your progress.
                Explore, ask questions, and build with intention.
              </p>
            </div>

            <div className="flex flex-wrap gap-3 mt-4">
              <a href={WHATSAPP_CHANNEL} target="_blank" className="btn-secondary px-6 py-3 rounded-full text-sm">WhatsApp Channel</a>
              <a href={WHATSAPP_COMMUNITY} target="_blank" className="btn-secondary px-6 py-3 rounded-full text-sm">Community Group</a>
            </div>
          </div>
        </div>

        {/* Floating Chatbot Button */}
        <button
          onClick={() => setShowChatbot(true)}
          className="fixed bottom-8 right-8 bg-[#3B82F6] hover:bg-[#2563EB] w-14 h-14 rounded-2xl flex items-center justify-center shadow-xl"
        >
          <MessageCircle size={24} />
        </button>

        {/* Embedded Zenvy Chat Modal */}
        <AnimatePresence>
          {showChatbot && (
            <div className="fixed inset-0 bg-black/90 z-[100] flex items-center justify-center p-4">
              <div className="w-full max-w-4xl bg-[#111111] rounded-3xl overflow-hidden border border-white/10 h-[620px] flex flex-col">
                <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between">
                  <div className="font-medium">Zenvy • Creator Camp Assistant</div>
                  <button onClick={() => setShowChatbot(false)} className="text-white/60 hover:text-white">Close</button>
                </div>
                <iframe 
                  src={HF_CHAT_URL} 
                  className="flex-1 w-full border-0" 
                />
              </div>
            </div>
          )}
        </AnimatePresence>
      </div>
    );
  }

  // Onboarding Stage
  if (stage === 'onboarding' && user) {
    return (
      <div className="app-container min-h-screen flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-2xl">
          <div className="flex justify-center mb-8">
            <img src="/logo.png" alt="Creator Camp" className="h-12" />
          </div>

          <div className="text-center mb-10">
            <div className="text-5xl font-semibold tracking-tighter">Welcome, {user.displayName.split(' ')[0]}</div>
            <p className="text-white/60 mt-3">Zenvy will now assess your fit for Creator Camp.</p>
          </div>

          <div className="card rounded-3xl p-8 md:p-10">
            <div className="space-y-5 max-h-[420px] overflow-y-auto pr-2 mb-8 custom-scroll">
              {messages.map((msg) => (
                <div key={msg.id} className={`flex ${msg.isAI ? 'justify-start' : 'justify-end'}`}>
                  <div className={`max-w-[85%] px-5 py-3.5 text-[15px] ${msg.isAI ? 'chat-bubble-ai' : 'chat-bubble-user'}`}>
                    {msg.text}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="chat-bubble-ai px-5 py-3.5">
                    <div className="flex gap-1">
                      <div className="w-1.5 h-1.5 bg-white/60 rounded-full animate-bounce" />
                      <div className="w-1.5 h-1.5 bg-white/60 rounded-full animate-bounce delay-100" />
                      <div className="w-1.5 h-1.5 bg-white/60 rounded-full animate-bounce delay-200" />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {!onboardingComplete && (
              <div className="flex gap-3">
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && sendOnboardingMessage()}
                  placeholder="Type your answer..."
                  className="input flex-1 px-6 py-4 rounded-2xl text-base"
                />
                <button 
                  onClick={sendOnboardingMessage}
                  disabled={!input.trim()}
                  className="btn-primary px-8 rounded-2xl font-medium disabled:opacity-50"
                >
                  Send
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Login Screen
  return (
    <div className="app-container min-h-screen flex items-center justify-center px-6">
      <div className="max-w-md w-full text-center">
        <div className="mb-10">
          <img src="/logo.png" alt="Creator Camp" className="h-14 mx-auto mb-6" />
          <div className="text-6xl font-semibold tracking-[-2.5px]">Creator Camp</div>
          <div className="mt-3 text-xl text-white/60">Guided by Zenvy</div>
        </div>

        <button 
          onClick={handleGoogleSignIn}
          className="w-full btn-primary py-4 rounded-2xl text-lg font-medium flex items-center justify-center gap-3"
        >
          Continue with Google
        </button>

        <p className="text-xs text-white/40 mt-8 max-w-[260px] mx-auto">
          By continuing, you agree to join Creator Camp and work with Zenvy.
        </p>
      </div>
    </div>
  );
}
